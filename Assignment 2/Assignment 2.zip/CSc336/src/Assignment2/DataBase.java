/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment2;

import java.sql.SQLException;

/**
 *
 * @author tenzintashi
 */
public class DataBase {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
        // TODO code application logic here
        
        // Testing 
        
        
        // PERSON CLASS
//        Persons person = new Persons();
        
        // Print 
//        System.out.println(person);
        
        // Insert person record in the relation
//        person.setId(29);
//        person.setName("Joanne");
//        person.setSex("F");
//        person.setPerson();
//        
//        person.setPerson();
//
        // Update record 
//        person.Update(30, "Dummy Record", "F");
        
        // Delete record
//        person.Delete(28);
//        person.Delete(29);
        
        
        // CHILD CLASS
//        Child child = new Child();
//        child.print(child.executeQuery(22, 21));
    
        // GRANDPARENTS CLASS
//        GrandParent grand_parent = new GrandParent();
//        grand_parent.print(grand_parent.executeQuery(1));


        // NEPHEW CLASS
//        Nephew nephew = new Nephew();
//        nephew.print(nephew.executeQuery(1));
        
        
        // BROTHER-IN-LAW CLASS
//        BrotherInLaw brother_in_law = new BrotherInLaw();
//        brother_in_law.print(brother_in_law.executeQuery(1));
        
        

    }
    
}
