/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment2;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author tenzintashi
 */
public class GrandParent extends Persons{
    /**
     * Query to find the grandparents of a given person
     * @param pId
     * @return 
     */
    public ResultSet executeQuery(int pId)
    {  
        try {
            if (conn != null) {
                String query = "SELECT Name As 'Child',\n"+
                                    "(SELECT Name FROM Persons WHERE Id IN\n"+
                                        "(SELECT fatherId FROM Family F2 WHERE F2.personId IN\n"+
                                            "(SELECT fatherId FROM Family F1 WHERE F1.personId = "+pId+" ))),\n"+
                                     "(SELECT Name FROM Persons WHERE Id IN\n"+
                                        "(SELECT motherId FROM Family F2 WHERE F2.personId IN\n"+
                                            "(SELECT fatherId FROM Family F1 WHERE F1.personId = "+pId+" ))),\n"+
                                     "(SELECT Name FROM Persons WHERE Id IN\n"+
                                        "(SELECT fatherId FROM Family F2 WHERE F2.personId IN\n"+
                                            "(SELECT motherId FROM Family F1 WHERE F1.personId = "+pId+" ))),\n"+
                                     "(SELECT Name FROM Persons WHERE Id IN\n"+
                                        "(SELECT motherId FROM Family F2 WHERE F2.personId IN\n"+
                                            "(SELECT motherId FROM Family F1 WHERE F1.personId = "+pId+" )))\n"+

                                "FROM Persons\n"+
                                "WHERE Id = "+pId;
                PreparedStatement statement = conn.prepareStatement(query);
                ResultSet result = statement.executeQuery(query);
                return result;
            }
            
               
            
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
    }
    
    /**
     * Method to print the query of grandparents
     * @param result 
     */
    public void print(ResultSet result){
        try {
            if (result != null) {
                System.out.println(String.format("%-20s \t %-20s \t %-20s \t %-20s \t %-20s ", 
                        "Child", "Paternal Grandfather", "Paternal Grandmother", "Maternal Grandfather", "Maternal Grandmother" ));
                while (result.next()) {
                    System.out.println(String.format("%-20s \t %-20s \t %-20s \t %-20s \t %-20s ",
                            result.getString(1),result.getString(2),result.getString(3),result.getString(4),result.getString(5)));
                }
            }
            
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    
}
