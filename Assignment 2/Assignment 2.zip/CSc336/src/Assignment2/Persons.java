/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment2;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author tenzintashi
 */


public class Persons implements SQLFamily {
    protected int Id;
    protected String Name;
    protected String Sex;
    
    ConnectSQLServer JavaToSQL = new ConnectSQLServer();
    Connection conn = JavaToSQL.SQLConnection();
    
    /**
     * default constructor
     */
    public Persons(){
        this.Name = null;
        this.Sex = null;
    }
    
    /**
     * overloaded constructor
     * @param personid
     * @param personName
     * @param personSex 
     */
    public Persons(int personid, String personName, String personSex){
        this.Id = personid;
        this.Name = personName;
        this.Sex = personSex; 
    }
    
    /**
     * Setter for the Id field
     * @param Id the Id to set
     */
    public void setId(int Id) {
        this.Id = Id;
    }
    
    /**
     * Setter for the Name field
     * @param Name the Name to set
     */
    public void setName(String Name) {
        this.Name = Name;
    }

    /**
     * Setter for the Sex field
     * @param sex the Sex to set
     */
    public void setSex(String sex) {
        this.Sex = sex;
    }

    /**
     * insert person object into the Person Table in the database
     */
    public void setPerson(){
        try {
            if (this.conn != null && this.Name != null && this.Sex != null) {
                String query = " insert into Persons (Id, Name, Sex)"
                + " values (?, ?, ?)";
                // create the mysql insert preparedstatement
                PreparedStatement preparedStmt = conn.prepareStatement(query);
                preparedStmt.setInt (1, this.Id);
                preparedStmt.setString(2, this.Name);
                preparedStmt.setString(3, this.Sex);
                // execute the preparedstatement
                preparedStmt.execute();
                System.out.println("New Person Added to Database Successfully");
            }else if(this.Name == null || this.Sex == null){
                System.out.println("Error!!!\nAll fields (Id, Name, Sex) are required");
            }    
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    
    /**
     * Find a person info using Id
     * @param personId 
     */
    public void getPerson(int personId){
        try {
             if (conn != null) {
                String sql = "SELECT * FROM Persons WHERE Id=?";

                PreparedStatement statement = conn.prepareStatement(sql);
                statement.setString(1, Integer.toString(personId));
                ResultSet result = statement.executeQuery();
                while (result.next()){
                    int pid = result.getInt(1);
                    String name = result.getString(2);
                    String sex = result.getString(3);

                    String output = "Data Found!!!\nId: %s\nName: %s \nSex: %s\n";
                    System.out.println(String.format(output, Integer.toString(pid), name, sex));
                }
            }
            
            
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    
    /**
     * 
     * @return formated String for a Persons Table
     */
    @Override 
    public String toString(){
        String output = "";
        try{
            // 1. Display the legend
            System.out.println(String.format("%-5s \t %-15s \t %.5s\n", "Id", "Name", "Sex"));
            // 2. Create a statement
            Statement myStmt = this.conn.createStatement();
            // 3. Execute SQL query
            ResultSet myRs = myStmt.executeQuery("select * from Persons");
            // 4. Process the result set
            while (myRs.next()) {
                output += String.format("%-5d \t %-15s \t %.5s\n", myRs.getInt("Id"), myRs.getString("Name"), myRs.getString("Sex"));

            }
        }catch(SQLException ex){
            ex.printStackTrace();
        }
        return output;
    }
    
    /**
     * Method to find a record on a database using person Id
     * @param personId 
     */
    @Override
    public void Select(int personId) {
        try {
            if (conn != null) {
                String sql = "SELECT * FROM Persons WHERE Id=?";

                PreparedStatement statement = conn.prepareStatement(sql);
                statement.setString(1, Integer.toString(personId));
                ResultSet result = statement.executeQuery();
                while (result.next()){
                    String pid = result.getString(1);
                    String name = result.getString(2);
                    String sex = result.getString(3);
                    System.out.println(String.format("%-5d \t %-15s \t %.5s\n", pid, name, sex));
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    
    /**
     * Method to update a record on a database
     * @param personId
     * @param Name
     * @param Sex 
     */
    @Override
    public void Update(int personId, String Name, String Sex) {
        try {
        if (conn != null) {
            String sql = "UPDATE Persons SET Name=?, Sex=? WHERE Id=?";

            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, Name);
            statement.setString(2, Sex);
            statement.setString(3, Integer.toString(personId));

            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("An existing user was updated successfully!");
            }
        }
        }catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
                try {
                        if (conn != null && !conn.isClosed()) {
                            //conn.close();
                        }
                    }   
                catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    /**
     * Method to delete a record from database
     * @param personId 
     */
    @Override
    public void Delete(int personId) {
        try {
        if (conn != null) {
            String sql = "DELETE FROM Persons WHERE Id=?";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, Integer.toString(personId));

            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("A user was deleted successfully!");
            }
        }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
                try {
                        if (conn != null && !conn.isClosed()) {
                            //conn.close();
                        }
                    }   
                catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    } 
}
