/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author tenzintashi
 */
public class ConnectSQLServer {
    /**
     * Method to connect the SQL database to Java application
     * @return 
     */
    public static Connection SQLConnection (){
    Connection conn = null;
        try {
            String dbURL = "jdbc:mysql://localhost:3306/Assignment";
            String user = "root";
            String pass = "12345678";
            conn = DriverManager.getConnection(dbURL, user, pass);
            if (conn != null) {
//               System.out.println("Connected to Database Successfully");
               return conn;
            }
        } 
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
}
}
