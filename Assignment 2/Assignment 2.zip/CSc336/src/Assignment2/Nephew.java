/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment2;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author tenzintashi
 */
public class Nephew extends Child{
    /**
     * 
     * @param personId
     * @return 
     */
    public ResultSet executeQuery(int personId){
        try {
            if (conn != null) {
                String sql = "SELECT Id, Name AS 'Nephew', Sex\n" +
                            "FROM Persons\n" +
                            "WHERE Id IN ((SELECT personId\n" +
                                            "FROM Family F1\n" +
                                            "WHERE F1.fatherId IN (SELECT brotherId \n" +
                                                                    "FROM Brothers F2 \n" +
                                                                    "WHERE F2.childId = "+personId+" and Sex = 'M'))\n" +
                                        "union\n" +
                                            "(SELECT personId \n" +
                                            "FROM Family F1 \n" +
                                            "WHERE F1.fatherId IN (SELECT brotherId \n" +
                                                                    "FROM BrotherSisters F2 \n" +
                                                                    "WHERE F2.sisterId = "+personId+" and Sex = 'M'))\n" +
                                        "union\n" +
                                            "(SELECT personId \n" +
                                            "FROM Family F1 \n" +
                                            "WHERE F1.motherId IN (SELECT sisterId \n" +
                                                                    "FROM BrotherSisters F2 \n" +
                                                                    "WHERE F2.brotherId = "+personId+" and Sex = 'M'))\n" +
                                        "union\n" +
                                            "(SELECT personId \n" +
                                            "FROM Family F1 \n" +
                                            "WHERE F1.motherId IN (SELECT sisterId \n" +
                                                                    "FROM Sisters F2 \n" +
                                                                    "WHERE F2.childId = "+personId+" and Sex = 'M'))\n" +
                                        "union\n" +
                                            "(SELECT personId\n" +
                                            "FROM Family F1\n" +
                                            "WHERE F1.fatherId In (SELECT husbandId FROM Spouses F2 WHERE F2.wifeId IN\n" +
                                                                "(SELECT sisterId FROM BrotherSisters F1 WHERE F1.brotherId = "+personId+")))\n" +
                                        "union\n" +
                                            "(SELECT personId\n" +
                                            "FROM Family F1\n" +
                                            "WHERE F1.fatherId In (SELECT husbandId FROM Spouses F2 WHERE F2.wifeId IN\n" +
                                                                "(SELECT sisterId FROM Sisters F1 WHERE F1.childId = "+personId+")))\n" +
                                        "union\n" +
                                            "(SELECT personId\n" +
                                            "FROM Family F1\n" +
                                            "WHERE F1.fatherId In (SELECT husbandId FROM Spouses F3 WHERE F3.wifeId IN\n" +
                                                                "(SELECT sisterId FROM Sisters F2 WHERE F2.childId IN\n" +
                                                                "(SELECT wifeId FROM Spouses F1 WHERE F1.husbandId = "+personId+"))))\n" +
                                        "union\n" +
                                            "(SELECT personId\n" +
                                            "FROM Family F1\n" +
                                            "WHERE F1.fatherId In (SELECT husbandId FROM Spouses F3 WHERE F3.wifeId IN\n" +
                                                                "(SELECT sisterId FROM BrotherSisters F2 WHERE F2.brotherId IN\n" +
                                                                "(SELECT husbandId FROM Spouses F1 WHERE F1.wifeId = "+personId+"))))\n" +
                                        "union\n" +
                                            "(SELECT personId\n" +
                                            "FROM Family F1\n" +
                                            "WHERE F1.fatherId In (SELECT brotherId FROM BrotherSisters F2 WHERE F2.sisterId IN\n" +
                                                                "(SELECT wifeId FROM Spouses F1 WHERE F1.husbandId = "+personId+")))\n" +
                                        "union\n" +
                                            "(SELECT personId\n" +
                                            "FROM Family F1\n" +
                                            "WHERE F1.fatherId In (SELECT brotherId FROM Brothers F2 WHERE F2.childId IN\n" +
                                                                "(SELECT husbandId FROM Spouses F1 WHERE F1.wifeId = "+personId+"))))";
                PreparedStatement statement = conn.prepareStatement(sql);
                ResultSet result = statement.executeQuery();
                return result;
            }
            
            
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
          return null;
    }
    
    
    @Override
    public void print(ResultSet m_result){
        // print nephew of a given person
        try {
            if (m_result != null) {
                System.out.println(String.format("%-15s \t %.5s\n", "Nephew", "Sex"));
                while (m_result.next()){
                    System.out.println(String.format("%-15s \t %.5s\n", m_result.getString(2), m_result.getString(3)));
                } 
            }
        }catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
                try {
                        if (m_result != null && !m_result.isClosed()) {
                            m_result.close();
                        }
                    }   
                catch (SQLException ex) {
            }
        }
    }
}
