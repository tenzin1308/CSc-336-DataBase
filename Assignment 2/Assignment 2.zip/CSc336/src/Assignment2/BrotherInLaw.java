/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment2;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author tenzintashi
 */
public class BrotherInLaw extends Persons{
    /**
     * Query to find the brother in law of a given person
     * @param personId
     * @return the query of brother in law
     */
    public ResultSet executeQuery(int personId)
    {  
        try {
            if (conn != null) {
                String query = "SELECT Name AS 'Brother In Law'\n" +
                                "FROM Persons\n" +
                                "WHERE Id IN ((SELECT husbandId FROM Spouses F2 WHERE F2.wifeId IN\n" +
                                                "(SELECT sisterId FROM BrotherSisters F1 WHERE F1.brotherId = "+personId+")),\n" +
                                            "(SELECT husbandId FROM Spouses F2 WHERE F2.wifeId IN\n" +
                                                "(SELECT sisterId FROM Sisters F1 WHERE F1.childId = "+personId+")),\n" +
                                            "(SELECT husbandId FROM Spouses F3 WHERE F3.wifeId IN\n" +
                                                "(SELECT sisterId FROM Sisters F2 WHERE F2.childId IN\n" +
                                                    "(SELECT wifeId FROM Spouses F1 WHERE F1.husbandId = "+personId+"))),\n" +
                                            "(SELECT husbandId FROM Spouses F3 WHERE F3.wifeId IN\n" +
                                                "(SELECT sisterId FROM BrotherSisters F2 WHERE F2.brotherId IN\n" +
                                                    "(SELECT husbandId FROM Spouses F1 WHERE F1.wifeId = "+personId+"))),\n" +
                                            "(SELECT brotherId FROM BrotherSisters F2 WHERE F2.sisterId IN\n" +
                                                "(SELECT wifeId FROM Spouses F1 WHERE F1.husbandId = "+personId+")),\n" +
                                            "(SELECT brotherId FROM Brothers F2 WHERE F2.childId IN\n" +
                                                "(SELECT husbandId FROM Spouses F1 WHERE F1.wifeId = "+personId+")))";
                PreparedStatement statement = conn.prepareStatement(query);
                ResultSet result = statement.executeQuery(query);
                return result;
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
    }
    
    /**
     * Method to print the query of brother in law
     * @param result 
     */
    public void print(ResultSet result)
    {
        // print brother in law of a given person
        
        try {
            if (result != null) {
                System.out.println(String.format("%-20s ", "Brother In Law"));
                while (result.next()) {
                    System.out.println(String.format("%-15s", result.getString(1)));
                }
            }
            
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
