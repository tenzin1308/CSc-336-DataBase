/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment2;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author tenzintashi
 */
public class Child extends Persons{
    
    /**
     * Query to find the child of a given couple
     * @param spouse1Id
     * @param spouse2Id
     * @return query of child
     */
    public ResultSet executeQuery(int spouse1Id, int spouse2Id){  
        try {
            if (conn != null) {
                Statement statement = conn.createStatement();
                String query = "SELECT ID, Name AS 'Child', sex\n"+
                               "FROM Persons\n"+
                               "WHERE Id IN (SELECT personId\n"+
                                            "From Family\n"+
                                            "WHERE fatherId ="+spouse1Id+" AND motherId ="+spouse2Id+
                                            " OR "
                                            +"fatherId =" + spouse2Id + " AND motherId =" + spouse1Id + ")";
                // System.out.println(query);
                ResultSet result = statement.executeQuery(query);
                return result;
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
    }
    
    /**
     * Method to print the child query
     * @param result 
     */
    public void print(ResultSet result)
    {
        // print children of a given couple
        
        try {
            if (result != null) {
                System.out.println(String.format("%-15s \t %.5s\n", "Child", "Sex"));
                while (result.next()) {
                    System.out.println(String.format("%-15s \t %.5s", result.getString(2), result.getString(3)));
                }
            }
            
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
